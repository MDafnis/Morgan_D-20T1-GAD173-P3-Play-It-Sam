#include "$safeitemname$.h"
#include "example.h"

$safeitemname$::$safeitemname$()
{
	m_sprite = kage::TextureManager::getSprite("data/zazaka.png");
	kage::centreOrigin(m_sprite);
	m_tags.add("$safeitemname$");

	m_physicsStyle = GameObject::e_psNewtonian;
}

$safeitemname$::~$safeitemname$()
{

}

void $safeitemname$::update(float deltaT)
{
	// Do logic here
}

void $safeitemname$::onCollision(GameObject *obj)
{
	//if (obj->m_tags.has("enemy"))
	//{
		//m_dead = true;		// kills itself
		//obj->m_dead = true;	// kills the other object
	//}
}
