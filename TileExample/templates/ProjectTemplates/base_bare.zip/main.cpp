#include "cmath"
#include "kf/kf_log.h"
#include "example.h"

using namespace std;

int main()
{
	Example::inst().run();

	return 0;
}
